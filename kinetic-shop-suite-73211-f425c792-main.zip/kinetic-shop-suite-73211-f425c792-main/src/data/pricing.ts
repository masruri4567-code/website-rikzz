export const tiktokPricing = {
  followersLuar: [
    { quantity: 100, price: 5000 },
    { quantity: 200, price: 9000 },
    { quantity: 300, price: 12000 },
    { quantity: 400, price: 14000 },
    { quantity: 500, price: 17000 },
    { quantity: 600, price: 20000 },
    { quantity: 700, price: 24000 },
  ],
  followersIndo: [
    { quantity: 100, price: 14000 },
    { quantity: 200, price: 22000 },
    { quantity: 300, price: 30000 },
    { quantity: 400, price: 40000 },
    { quantity: 500, price: 50000 },
    { quantity: 600, price: 59000 },
    { quantity: 700, price: 67000 },
  ],
  likes: [
    { quantity: 100, price: 3000 },
    { quantity: 200, price: 5000 },
    { quantity: 300, price: 7000 },
    { quantity: 400, price: 9000 },
    { quantity: 500, price: 11000 },
    { quantity: 1000, price: 16000 },
    { quantity: 2000, price: 20000 },
  ],
  views: [
    { quantity: 100, price: 2000 },
    { quantity: 200, price: 4000 },
    { quantity: 300, price: 6000 },
    { quantity: 400, price: 8000 },
    { quantity: 500, price: 10000 },
    { quantity: 1000, price: 15000 },
    { quantity: 2000, price: 20000 },
  ],
};

export const instagramPricing = {
  followersLuar: [
    { quantity: 100, price: 8000 },
    { quantity: 200, price: 14000 },
    { quantity: 300, price: 18000 },
    { quantity: 400, price: 23000 },
    { quantity: 500, price: 28000 },
    { quantity: 600, price: 32000 },
    { quantity: 700, price: 37000 },
  ],
  followersIndo: [
    { quantity: 100, price: 11000 },
    { quantity: 200, price: 18000 },
    { quantity: 300, price: 25000 },
    { quantity: 400, price: 32000 },
    { quantity: 500, price: 39000 },
    { quantity: 600, price: 45000 },
    { quantity: 700, price: 52000 },
  ],
  likes: [
    { quantity: 100, price: 3000 },
    { quantity: 200, price: 6000 },
    { quantity: 300, price: 9000 },
    { quantity: 400, price: 12000 },
    { quantity: 500, price: 15000 },
    { quantity: 600, price: 18000 },
    { quantity: 700, price: 21000 },
  ],
  views: [
    { quantity: 100, price: 2000 },
    { quantity: 200, price: 4000 },
    { quantity: 300, price: 6000 },
    { quantity: 400, price: 8000 },
    { quantity: 500, price: 10000 },
    { quantity: 1000, price: 15000 },
    { quantity: 2000, price: 20000 },
  ],
};

export const botRentalPricing = {
  premiumMember: [
    { duration: "3 Minggu", price: 10000 },
    { duration: "1 Bulan", price: 15000 },
    { duration: "2 Bulan", price: 30000 },
    { duration: "3 Bulan", price: 45000 },
    { duration: "4 Bulan", price: 60000 },
  ],
  premiumAllAdmin: [
    { duration: "3 Minggu", price: 25000 },
    { duration: "1 Bulan", price: 30000 },
    { duration: "2 Bulan", price: 50000 },
    { duration: "3 Bulan", price: 70000 },
    { duration: "4 Bulan", price: 90000 },
  ],
};

// Premium Member pricing - 1 day = 1k IDR
export const premiumMemberPricing = Array.from({ length: 30 }, (_, i) => ({
  days: i + 1,
  price: (i + 1) * 1000,
}));

export const whatsappPricing = {
  channelMember: [
    { quantity: 100, price: 9000 },
    { quantity: 200, price: 13000 },
    { quantity: 300, price: 18000 },
    { quantity: 400, price: 22000 },
    { quantity: 500, price: 26000 },
    { quantity: 600, price: 31000 },
    { quantity: 700, price: 35000 },
  ],
  reaction: [
    { quantity: 100, price: 5000 },
    { quantity: 200, price: 7000 },
    { quantity: 300, price: 9000 },
    { quantity: 400, price: 12000 },
    { quantity: 500, price: 15000 },
    { quantity: 600, price: 17000 },
    { quantity: 700, price: 20000 },
  ],
};

export const facebookPricing = {
  followersLuar: [
    { quantity: 100, price: 5000 },
    { quantity: 200, price: 7000 },
    { quantity: 300, price: 9000 },
    { quantity: 400, price: 11000 },
    { quantity: 500, price: 13000 },
    { quantity: 600, price: 15000 },
    { quantity: 700, price: 17000 },
  ],
  followersIndo: [
    { quantity: 100, price: 15000 },
    { quantity: 200, price: 25000 },
    { quantity: 300, price: 35000 },
    { quantity: 400, price: 45000 },
    { quantity: 500, price: 56000 },
    { quantity: 600, price: 67000 },
    { quantity: 700, price: 76000 },
  ],
  groupMember: [
    { quantity: 100, price: 7000 },
    { quantity: 200, price: 9000 },
    { quantity: 300, price: 12000 },
    { quantity: 400, price: 15000 },
    { quantity: 500, price: 17000 },
    { quantity: 600, price: 19000 },
    { quantity: 700, price: 21000 },
  ],
  likes: [
    { quantity: 50, price: 1000 },
    { quantity: 100, price: 2000 },
    { quantity: 200, price: 4000 },
    { quantity: 300, price: 6000 },
    { quantity: 400, price: 8000 },
    { quantity: 500, price: 10000 },
    { quantity: 600, price: 12000 },
    { quantity: 700, price: 14000 },
    { quantity: 800, price: 16000 },
    { quantity: 900, price: 18000 },
    { quantity: 1000, price: 20000 },
    { quantity: 2000, price: 30000 },
  ],
  views: [
    { quantity: 50, price: 500 },
    { quantity: 100, price: 1000 },
    { quantity: 200, price: 1500 },
    { quantity: 300, price: 2000 },
    { quantity: 400, price: 2500 },
    { quantity: 500, price: 3000 },
    { quantity: 600, price: 3500 },
    { quantity: 700, price: 4000 },
    { quantity: 800, price: 5000 },
    { quantity: 900, price: 6000 },
    { quantity: 1000, price: 7000 },
    { quantity: 2000, price: 10000 },
  ],
};

import { User, MapPin, Calendar, Mail, Phone, Building2, Award } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";

const Contact = () => {
  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-primary/5 to-secondary/5 py-12 px-4 animate-fade-in">
      <div className="max-w-5xl mx-auto space-y-8">
        {/* Header */}
        <div className="text-center space-y-4 animate-scale-in">
          <h1 className="text-4xl md:text-5xl font-bold text-foreground">
            Hubungi Kami
          </h1>
          <p className="text-muted-foreground text-lg max-w-2xl mx-auto">
            Kami siap membantu Anda. Jangan ragu untuk menghubungi tim kami kapan saja.
          </p>
        </div>

        {/* CEO Profile Card */}
        <Card className="overflow-hidden border-2 hover:shadow-2xl transition-all duration-300 animate-fade-in">
          <div className="h-2 bg-gradient-primary" />
          <CardContent className="p-8 space-y-8">
            {/* CEO Header */}
            <div className="flex flex-col md:flex-row items-center gap-6">
              <div className="w-32 h-32 rounded-2xl bg-gradient-primary flex items-center justify-center shadow-lg">
                <User className="w-16 h-16 text-white" />
              </div>
              <div className="text-center md:text-left space-y-2">
                <h2 className="text-3xl font-bold text-foreground">Bariklana Dwimeirizki</h2>
                <p className="text-xl text-primary font-semibold">CEO & Founder</p>
                <div className="flex items-center gap-2 justify-center md:justify-start text-muted-foreground">
                  <Building2 className="w-4 h-4" />
                  <span>Lyra Group</span>
                </div>
              </div>
            </div>

            <div className="h-px bg-gradient-primary opacity-20" />

            {/* Contact Info */}
            <div className="space-y-4">
              <h3 className="text-lg font-bold flex items-center gap-2 text-foreground">
                <Mail className="w-5 h-5 text-primary" />
                Informasi Kontak
              </h3>
              
              <div className="space-y-4">
                <a 
                  href="mailto:ceo@barikmarket.com"
                  className="flex items-start gap-3 p-4 rounded-xl bg-muted/50 hover:bg-primary hover:text-white transition-all duration-300 group"
                >
                  <Mail className="w-5 h-5 mt-0.5 text-primary group-hover:text-white flex-shrink-0" />
                  <div>
                    <p className="font-semibold mb-1">Email</p>
                    <p className="opacity-90">ceo@barikmarket.com</p>
                  </div>
                </a>

                <a 
                  href="tel:+6281559556419"
                  className="flex items-start gap-3 p-4 rounded-xl bg-muted/50 hover:bg-secondary hover:text-white transition-all duration-300 group"
                >
                  <Phone className="w-5 h-5 mt-0.5 text-secondary group-hover:text-white flex-shrink-0" />
                  <div>
                    <p className="font-semibold mb-1">Telepon</p>
                    <p className="opacity-90">+62 815-5955-6419</p>
                  </div>
                </a>
              </div>
            </div>

            <div className="h-px bg-gradient-primary opacity-20" />

            {/* About Section */}
            <div className="space-y-4">
              <h3 className="text-lg font-bold text-foreground">Tentang CEO</h3>
              <div className="bg-gradient-primary/10 rounded-xl p-6 space-y-4">
                <p className="text-muted-foreground leading-relaxed">
                  Pendiri dan CEO dari <span className="font-bold text-primary">Lyra Group</span>, 
                  sebuah perusahaan yang fokus pada solusi digital marketing dan automation. 
                  Dengan dedikasi tinggi di industri teknologi dan pemasaran digital, 
                  beliau memimpin Barik Market untuk memberikan layanan terbaik kepada klien.
                </p>
              </div>
            </div>

            {/* Vision & Mission */}
            <div className="space-y-4">
              <h3 className="text-lg font-bold text-foreground">Visi & Misi</h3>
              <div className="bg-gradient-to-br from-primary/10 to-secondary/10 rounded-xl p-6">
                <p className="text-muted-foreground leading-relaxed">
                  Menciptakan ekosistem digital yang memberdayakan bisnis kecil hingga besar 
                  untuk berkembang melalui teknologi dan strategi pemasaran yang inovatif. 
                  Kami percaya bahwa setiap bisnis berhak mendapatkan akses ke tools dan 
                  strategi marketing terbaik untuk mencapai kesuksesan mereka.
                </p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Company Info Card */}
        <Card className="border-2 hover:shadow-xl transition-all duration-300 animate-fade-in">
          <CardContent className="p-8">
            <h3 className="text-2xl font-bold mb-6 flex items-center gap-2 text-foreground">
              <Building2 className="w-6 h-6 text-primary" />
              Tentang Barik Market
            </h3>
            <p className="text-muted-foreground leading-relaxed mb-4">
              Barik Market adalah platform terpercaya untuk layanan digital marketing dan 
              peningkatan engagement media sosial. Kami menyediakan solusi lengkap untuk 
              TikTok dan Instagram, termasuk followers, likes, views, dan layanan bot rental.
            </p>
            <p className="text-muted-foreground leading-relaxed">
              Dengan sistem pembayaran yang mudah dan aman melalui berbagai metode pembayaran 
              Indonesia (QRIS, GoPay, OVO, Dana, ShopeePay), kami memastikan proses transaksi 
              Anda berjalan lancar dan cepat.
            </p>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default Contact;

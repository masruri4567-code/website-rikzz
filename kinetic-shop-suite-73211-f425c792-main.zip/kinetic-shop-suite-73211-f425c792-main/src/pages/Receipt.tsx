import { useLocation, useNavigate, Link } from "react-router-dom";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { ShoppingCart, Calendar, Hash, Copy, CreditCard } from "lucide-react";
import { OrderItem } from "@/types/order";
import { useEffect } from "react";
import { useToast } from "@/hooks/use-toast";

const Receipt = () => {
  const location = useLocation();
  const navigate = useNavigate();
  const { toast } = useToast();
  const { cart, total, paymentMethod } = location.state || { cart: [], total: 0, paymentMethod: "QRIS" };

  useEffect(() => {
    if (!cart || cart.length === 0) {
      navigate("/order");
    }
  }, [cart, navigate]);

  if (!cart || cart.length === 0) {
    return null;
  }

  const orderId = `ORD-${Date.now()}`;
  const orderDate = new Date().toLocaleString("id-ID", {
    day: "2-digit",
    month: "long",
    year: "numeric",
    hour: "2-digit",
    minute: "2-digit",
  });

  const formatPrice = (price: number) => {
    return new Intl.NumberFormat("id-ID", {
      style: "currency",
      currency: "IDR",
      minimumFractionDigits: 0,
    }).format(price);
  };

  const generateWhatsAppMessage = () => {
    let message = `*DETAIL PESANAN*\n\n`;
    message += `ID Pesanan: ${orderId}\n`;
    message += `Tanggal: ${orderDate}\n`;
    message += `Metode Pembayaran: ${paymentMethod}\n\n`;
    message += `*ITEM PESANAN:*\n`;
    
    cart.forEach((item: OrderItem, index: number) => {
      message += `\n${index + 1}. ${item.name}\n`;
      
      if (item.type === "social-media") {
        const service = item.service as any;
        message += `   Platform: ${service.platform.toUpperCase()}\n`;
        message += `   Kategori: ${service.category}\n`;
        message += `   Jumlah: ${service.quantity}\n`;
        if (item.link) {
          message += `   Link: ${item.link}\n`;
        }
        message += `   Harga: ${formatPrice(service.price)}\n`;
      } else if (item.type === "bot-rental") {
        const service = item.service as any;
        message += `   Layanan: Sewa Bot WhatsApp\n`;
        message += `   Durasi: ${service.duration}\n`;
        message += `   Harga: ${formatPrice(service.price)}\n`;
      } else if (item.type === "premium-member") {
        const service = item.service as any;
        message += `   Layanan: Premium Member\n`;
        message += `   Durasi: ${service.days} hari\n`;
        message += `   Harga: ${formatPrice(service.price)}\n`;
      }
    });

    message += `\n*TOTAL: ${formatPrice(total)}*\n\n`;
    message += `Mohon konfirmasi pesanan ini. Terima kasih!`;

    return encodeURIComponent(message);
  };

  const handleWhatsAppOrder = () => {
    const message = generateWhatsAppMessage();
    const whatsappUrl = `https://wa.me/6281559556419?text=${message}`;
    window.open(whatsappUrl, "_blank");
  };

  const getPaymentAccountNumber = () => {
    if (paymentMethod === "DANA" || paymentMethod === "OVO" || paymentMethod === "GoPay") {
      return { number: "082141903060", name: "Bariklana Dwimeirizki" };
    } else if (paymentMethod === "SeaBank") {
      return { number: "901252487683", name: "Bariklana Dwimeirizki" };
    } else if (paymentMethod === "BCA") {
      return { number: "0902067521", name: "Meydina Lestari" };
    }
    return null;
  };

  const handleCopyAccountNumber = () => {
    const accountInfo = getPaymentAccountNumber();
    if (accountInfo) {
      navigator.clipboard.writeText(accountInfo.number);
      toast({
        title: "Berhasil disalin",
        description: `Nomor rekening ${accountInfo.number} telah disalin ke clipboard`,
      });
    }
  };

  return (
    <div className="min-h-screen py-12 px-6">
      <div className="max-w-3xl mx-auto space-y-8">
        <div className="text-center space-y-4 animate-fade-in">
          <div className="w-20 h-20 bg-green-100 dark:bg-green-900/30 rounded-full flex items-center justify-center mx-auto mb-4">
            <ShoppingCart className="w-10 h-10 text-green-600 dark:text-green-400" />
          </div>
          <h1 className="text-4xl font-bold text-foreground">Struk Pesanan</h1>
          <p className="text-lg font-semibold text-foreground">Barik Market</p>
          <p className="text-sm text-muted-foreground">Dikelola oleh PT Lyra Group</p>
          <p className="text-muted-foreground">
            Pesanan Anda telah diterima. Silakan konfirmasi via WhatsApp.
          </p>
        </div>

        <Card className="p-8 space-y-6 animate-scale-in">
          <div className="space-y-4 pb-6 border-b border-border">
            <div className="flex items-center gap-3">
              <Hash className="w-5 h-5 text-muted-foreground" />
              <div>
                <p className="text-sm text-muted-foreground">ID Pesanan</p>
                <p className="font-bold">{orderId}</p>
              </div>
            </div>
            
            <div className="flex items-center gap-3">
              <Calendar className="w-5 h-5 text-muted-foreground" />
              <div>
                <p className="text-sm text-muted-foreground">Tanggal</p>
                <p className="font-bold">{orderDate}</p>
              </div>
            </div>

            <div className="flex items-center gap-3">
              <CreditCard className="w-5 h-5 text-muted-foreground" />
              <div className="flex-1">
                <p className="text-sm text-muted-foreground">Metode Pembayaran</p>
                <p className="font-bold">{paymentMethod}</p>
              </div>
            </div>

            {getPaymentAccountNumber() && (
              <div className="p-4 bg-primary/5 rounded-lg border border-primary/20 space-y-2">
                <p className="text-sm text-muted-foreground">Nomor Pembayaran</p>
                <div className="flex items-center justify-between gap-4">
                  <div>
                    <p className="text-lg font-bold text-primary">{getPaymentAccountNumber().number}</p>
                    <p className="text-xs text-muted-foreground">a.n. {getPaymentAccountNumber().name}</p>
                  </div>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={handleCopyAccountNumber}
                    className="shrink-0"
                  >
                    <Copy className="w-4 h-4 mr-2" />
                    Salin
                  </Button>
                </div>
              </div>
            )}
          </div>

          <div className="space-y-4">
            <h2 className="text-xl font-bold">Detail Pesanan</h2>
            {cart.map((item: OrderItem, index: number) => (
              <div
                key={item.id}
                className="p-4 rounded-xl bg-muted/50 border border-border space-y-2"
              >
                <div className="flex justify-between items-start">
                  <span className="font-medium text-sm text-muted-foreground">
                    Item #{index + 1}
                  </span>
                </div>
                
                <p className="font-semibold">{item.name}</p>
                
                {item.type === "social-media" ? (
                  <div className="text-sm space-y-1">
                    <p className="text-muted-foreground">
                      Platform: <span className="font-medium text-foreground">
                        {(item.service as any).platform.toUpperCase()}
                      </span>
                    </p>
                    <p className="text-muted-foreground">
                      Kategori: <span className="font-medium text-foreground">
                        {(item.service as any).category}
                      </span>
                    </p>
                    <p className="text-muted-foreground">
                      Jumlah: <span className="font-medium text-foreground">
                        {(item.service as any).quantity}
                      </span>
                    </p>
                    {item.link && (
                      <p className="text-muted-foreground truncate">
                        Link: <span className="font-medium text-foreground">
                          {item.link}
                        </span>
                      </p>
                    )}
                  </div>
                ) : item.type === "bot-rental" ? (
                  <div className="text-sm space-y-1">
                    <p className="text-muted-foreground">
                      Layanan: <span className="font-medium text-foreground">
                        Sewa Bot WhatsApp
                      </span>
                    </p>
                    <p className="text-muted-foreground">
                      Durasi: <span className="font-medium text-foreground">
                        {(item.service as any).duration}
                      </span>
                    </p>
                  </div>
                ) : (
                  <div className="text-sm space-y-1">
                    <p className="text-muted-foreground">
                      Layanan: <span className="font-medium text-foreground">
                        Premium Member
                      </span>
                    </p>
                    <p className="text-muted-foreground">
                      Durasi: <span className="font-medium text-foreground">
                        {(item.service as any).days} hari
                      </span>
                    </p>
                  </div>
                )}
                
                <p className="font-bold text-primary pt-2">
                  {formatPrice((item.service as any).price)}
                </p>
              </div>
            ))}
          </div>

          <div className="pt-6 border-t border-border space-y-4">
            <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-2 text-xl sm:text-2xl font-bold">
              <span className="text-foreground">Total Pembayaran</span>
              <span className="text-primary break-all">{formatPrice(total)}</span>
            </div>

            <Button
              onClick={handleWhatsAppOrder}
              className="w-full bg-green-600 hover:bg-green-700 text-white"
              size="lg"
            >
              Pesan via WhatsApp
            </Button>

            <Link to="/order">
              <Button variant="outline" className="w-full">
                Buat Pesanan Baru
              </Button>
            </Link>

            <div className="pt-6 border-t border-border text-center space-y-2">
              <p className="text-lg font-semibold text-foreground">Terima kasih atas kepercayaan Anda</p>
              <p className="text-sm text-muted-foreground">Barik Market - PT Lyra Group</p>
            </div>
          </div>
        </Card>
      </div>
    </div>
  );
};

export default Receipt;

import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Card } from "@/components/ui/card";
import { Plus, Trash2, ShoppingCart } from "lucide-react";
import { tiktokPricing, instagramPricing, whatsappPricing, facebookPricing, botRentalPricing, premiumMemberPricing } from "@/data/pricing";
import { OrderItem } from "@/types/order";
import { useNavigate } from "react-router-dom";
import { toast } from "sonner";

const Order = () => {
  const navigate = useNavigate();
  const [orderType, setOrderType] = useState<"social-media" | "bot-rental" | "premium-member">("social-media");
  const [cart, setCart] = useState<OrderItem[]>([]);

  // Form states
  const [name, setName] = useState("");
  const [platform, setPlatform] = useState<"tiktok" | "instagram" | "whatsapp" | "facebook">("tiktok");
  const [category, setCategory] = useState("");
  const [quantity, setQuantity] = useState("");
  const [link, setLink] = useState("");
  const [botPackage, setBotPackage] = useState<"premiumMember" | "premiumAllAdmin">("premiumMember");
  const [botDuration, setBotDuration] = useState("");
  const [premiumDays, setPremiumDays] = useState("");

  const getPricing = () => {
    if (orderType === "bot-rental") return [];
    let pricing: any;
    if (platform === "tiktok") pricing = tiktokPricing;
    else if (platform === "instagram") pricing = instagramPricing;
    else if (platform === "whatsapp") pricing = whatsappPricing;
    else if (platform === "facebook") pricing = facebookPricing;
    return pricing?.[category as keyof typeof pricing] || [];
  };

  const getPrice = () => {
    if (orderType === "bot-rental") {
      const rental = botRentalPricing[botPackage].find(r => r.duration === botDuration);
      return rental?.price || 0;
    }
    if (orderType === "premium-member") {
      const premium = premiumMemberPricing.find(p => p.days === parseInt(premiumDays));
      return premium?.price || 0;
    }
    const pricing = getPricing();
    const item = pricing.find(p => p.quantity === parseInt(quantity));
    return item?.price || 0;
  };

  const addToCart = () => {
    if (orderType === "social-media") {
      if (!name || !platform || !category || !quantity || !link) {
        toast.error("Mohon lengkapi semua field");
        return;
      }
    } else if (orderType === "bot-rental") {
      if (!name || !botDuration || !botPackage) {
        toast.error("Mohon lengkapi semua field");
        return;
      }
    } else if (orderType === "premium-member") {
      if (!name || !premiumDays) {
        toast.error("Mohon lengkapi semua field");
        return;
      }
    }

    const price = getPrice();
    if (price === 0) {
      toast.error("Harga tidak ditemukan");
      return;
    }

    const newItem: OrderItem = {
      id: Date.now().toString(),
      type: orderType as any,
      name,
      link: orderType === "social-media" ? link : undefined,
      service: orderType === "social-media"
        ? { platform, category, quantity: parseInt(quantity), price }
        : orderType === "bot-rental"
        ? { duration: botDuration, price, package: botPackage }
        : { days: parseInt(premiumDays), price }
    };

    setCart([...cart, newItem]);
    toast.success("Item ditambahkan ke keranjang");

    // Reset form
    setName("");
    setLink("");
    setQuantity("");
    setBotDuration("");
    setPremiumDays("");
  };

  const removeFromCart = (id: string) => {
    setCart(cart.filter(item => item.id !== id));
    toast.success("Item dihapus dari keranjang");
  };

  const getTotalPrice = () => {
    return cart.reduce((total, item) => {
      if (item.type === "social-media") {
        return total + (item.service as any).price;
      }
      return total + (item.service as any).price;
    }, 0);
  };

  const handleCheckout = () => {
    if (cart.length === 0) {
      toast.error("Keranjang masih kosong");
      return;
    }
    navigate("/payment", { state: { cart, total: getTotalPrice() } });
  };

  const formatPrice = (price: number) => {
    return new Intl.NumberFormat("id-ID", {
      style: "currency",
      currency: "IDR",
      minimumFractionDigits: 0,
    }).format(price);
  };

  return (
    <div className="min-h-screen py-12 px-6">
      <div className="max-w-6xl mx-auto space-y-8">
        <div className="text-center space-y-4 animate-fade-in">
          <h1 className="text-4xl md:text-5xl font-bold">Buat Pesanan</h1>
          <p className="text-xl text-muted-foreground">
            Isi form di bawah untuk membuat pesanan
          </p>
        </div>

        <div className="grid lg:grid-cols-2 gap-8">
          {/* Order Form */}
          <Card className="p-8 space-y-6 animate-fade-in">
            <div className="space-y-4">
              <div>
                <Label>Tipe Layanan</Label>
                <Select value={orderType} onValueChange={(v: any) => setOrderType(v)}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="social-media">Suntik Sosmed</SelectItem>
                    <SelectItem value="bot-rental">Sewa Bot WhatsApp</SelectItem>
                    <SelectItem value="premium-member">Premium Member</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Label>Nama</Label>
                <Input
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="Masukkan nama Anda"
                />
              </div>

              {orderType === "social-media" ? (
                <>
                  <div>
                    <Label>Platform</Label>
                    <Select value={platform} onValueChange={(v: any) => { setPlatform(v); setCategory(""); }}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="tiktok">TikTok</SelectItem>
                        <SelectItem value="instagram">Instagram</SelectItem>
                        <SelectItem value="whatsapp">WhatsApp</SelectItem>
                        <SelectItem value="facebook">Facebook</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div>
                    <Label>Kategori</Label>
                    <Select value={category} onValueChange={setCategory}>
                      <SelectTrigger>
                        <SelectValue placeholder="Pilih kategori" />
                      </SelectTrigger>
                      <SelectContent>
                        {(platform === "tiktok" || platform === "instagram") && (
                          <>
                            <SelectItem value="followersLuar">Followers Luar</SelectItem>
                            <SelectItem value="followersIndo">Followers Indo</SelectItem>
                            <SelectItem value="likes">Likes</SelectItem>
                            <SelectItem value="views">Views</SelectItem>
                          </>
                        )}
                        {platform === "whatsapp" && (
                          <>
                            <SelectItem value="channelMember">Channel Member</SelectItem>
                            <SelectItem value="reaction">Reaction</SelectItem>
                          </>
                        )}
                        {platform === "facebook" && (
                          <>
                            <SelectItem value="followersLuar">Follow Luar</SelectItem>
                            <SelectItem value="followersIndo">Follow Indo</SelectItem>
                            <SelectItem value="groupMember">Group Member</SelectItem>
                            <SelectItem value="likes">Likes Post</SelectItem>
                            <SelectItem value="views">View Video</SelectItem>
                          </>
                        )}
                      </SelectContent>
                    </Select>
                  </div>

                  <div>
                    <Label>Jumlah</Label>
                    <Select value={quantity} onValueChange={setQuantity}>
                      <SelectTrigger>
                        <SelectValue placeholder="Pilih jumlah" />
                      </SelectTrigger>
                      <SelectContent>
                        {getPricing().map((item) => (
                          <SelectItem key={item.quantity} value={item.quantity.toString()}>
                            {item.quantity} - {formatPrice(item.price)}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  <div>
                    <Label>Link Target</Label>
                    <Input
                      value={link}
                      onChange={(e) => setLink(e.target.value)}
                      placeholder="Masukkan link post/profil"
                    />
                  </div>
                </>
              ) : orderType === "bot-rental" ? (
                <>
                  <div>
                    <Label>Paket Bot</Label>
                    <Select value={botPackage} onValueChange={(v: any) => setBotPackage(v)}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="premiumMember">Paket Sewa + Premium Member (1 User)</SelectItem>
                        <SelectItem value="premiumAllAdmin">Paket Sewa + Premium All Admin (Maks. 5 Admin)</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <Label>Durasi Sewa</Label>
                    <Select value={botDuration} onValueChange={setBotDuration}>
                      <SelectTrigger>
                        <SelectValue placeholder="Pilih durasi" />
                      </SelectTrigger>
                      <SelectContent>
                        {botRentalPricing[botPackage].map((item) => (
                          <SelectItem key={item.duration} value={item.duration}>
                            {item.duration} - {formatPrice(item.price)}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                </>
              ) : (
                <div>
                  <Label>Durasi Premium (Hari)</Label>
                  <Select value={premiumDays} onValueChange={setPremiumDays}>
                    <SelectTrigger>
                      <SelectValue placeholder="Pilih durasi" />
                    </SelectTrigger>
                    <SelectContent className="max-h-[300px]">
                      {premiumMemberPricing.map((item) => (
                        <SelectItem key={item.days} value={item.days.toString()}>
                          {item.days} Hari - {formatPrice(item.price)}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  <p className="text-xs text-muted-foreground mt-2">
                    💎 Premium Member: Rp 1.000/hari | Nikmati benefit eksklusif!
                  </p>
                </div>
              )}

              <Button onClick={addToCart} className="w-full bg-gradient-primary hover:opacity-90 text-white">
                <Plus className="mr-2 h-4 w-4" />
                Tambah ke Keranjang
              </Button>
            </div>
          </Card>

          {/* Cart */}
          <Card className="p-8 space-y-6 animate-fade-in">
            <div className="flex items-center gap-2 pb-4 border-b border-border">
              <ShoppingCart className="h-5 w-5" />
              <h2 className="text-2xl font-bold">Keranjang ({cart.length})</h2>
            </div>

            <div className="space-y-4 max-h-96 overflow-y-auto">
              {cart.length === 0 ? (
                <p className="text-center text-muted-foreground py-8">
                  Keranjang masih kosong
                </p>
              ) : (
                cart.map((item) => (
                  <div
                    key={item.id}
                    className="p-4 rounded-xl bg-muted/50 border border-border space-y-2"
                  >
                    <div className="flex justify-between items-start">
                      <div className="space-y-1 flex-1">
                        <p className="font-medium">{item.name}</p>
                        {item.type === "social-media" ? (
                          <>
                            <p className="text-sm text-muted-foreground">
                              {(item.service as any).platform.toUpperCase()} - {(item.service as any).category}
                            </p>
                            <p className="text-sm text-muted-foreground">
                              Jumlah: {(item.service as any).quantity}
                            </p>
                          </>
                        ) : item.type === "bot-rental" ? (
                          <p className="text-sm text-muted-foreground">
                            Bot Rental - {(item.service as any).duration}
                          </p>
                        ) : (
                          <p className="text-sm text-muted-foreground">
                            💎 Premium Member - {(item.service as any).days} Hari
                          </p>
                        )}
                        <p className="font-bold text-primary">
                          {formatPrice((item.service as any).price)}
                        </p>
                      </div>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => removeFromCart(item.id)}
                        className="text-destructive hover:text-destructive"
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                ))
              )}
            </div>

            {cart.length > 0 && (
              <div className="space-y-4 pt-4 border-t border-border">
                <div className="flex justify-between items-center text-xl font-bold">
                  <span>Total</span>
                  <span className="text-primary">{formatPrice(getTotalPrice())}</span>
                </div>
                <Button
                  onClick={handleCheckout}
                  className="w-full bg-gradient-primary hover:opacity-90 text-white"
                  size="lg"
                >
                  Checkout
                </Button>
              </div>
            )}
          </Card>
        </div>
      </div>
    </div>
  );
};

export default Order;

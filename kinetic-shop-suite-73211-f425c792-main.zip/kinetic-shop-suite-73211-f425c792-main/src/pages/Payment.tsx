import { useState } from "react";
import { useLocation, useNavigate } from "react-router-dom";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Download, CheckCircle } from "lucide-react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import qrisImage from "@/assets/qris-payment.jpeg";
import qrisLogo from "@/assets/qris-logo.jpg";
import gopayLogo from "@/assets/gopay-logo.jpg";
import seabankLogo from "@/assets/shopeepay-logo.jpg";
import ovoLogo from "@/assets/ovo-logo.jpg";
import danaLogo from "@/assets/dana-logo.jpg";
import bcaLogo from "@/assets/bca-logo.jpg";
import { toast } from "sonner";

const Payment = () => {
  const location = useLocation();
  const navigate = useNavigate();
  const { cart, total } = location.state || { cart: [], total: 0 };
  const [selectedMethod, setSelectedMethod] = useState("");
  const [showQRIS, setShowQRIS] = useState(false);

  if (!cart || cart.length === 0) {
    navigate("/order");
    return null;
  }

  const paymentMethods = [
    { id: "dana", name: "DANA", logo: danaLogo },
    { id: "qris", name: "QRIS", logo: qrisLogo },
    { id: "ovo", name: "OVO", logo: ovoLogo },
    { id: "gopay", name: "GoPay", logo: gopayLogo },
    { id: "seabank", name: "SeaBank", logo: seabankLogo },
    { id: "bca", name: "BCA", logo: bcaLogo },
  ];

  const formatPrice = (price: number) => {
    return new Intl.NumberFormat("id-ID", {
      style: "currency",
      currency: "IDR",
      minimumFractionDigits: 0,
    }).format(price);
  };

  const handlePaymentSelect = (methodId: string) => {
    setSelectedMethod(methodId);
    const paymentMethodName = paymentMethods.find(m => m.id === methodId)?.name || methodId.toUpperCase();
    if (methodId === "qris") {
      setShowQRIS(true);
    } else {
      // For other payment methods, go directly to receipt
      toast.success(`Pembayaran melalui ${methodId.toUpperCase()} berhasil!`);
      setTimeout(() => {
        navigate("/receipt", { state: { cart, total, paymentMethod: paymentMethodName } });
      }, 1000);
    }
  };

  const handleDownloadQRIS = () => {
    const link = document.createElement("a");
    link.href = qrisImage;
    link.download = "qris-payment.jpeg";
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    toast.success("QRIS berhasil diunduh");
  };

  const handleProceedToReceipt = () => {
    const paymentMethodName = paymentMethods.find(m => m.id === selectedMethod)?.name || "QRIS";
    navigate("/receipt", { state: { cart, total, paymentMethod: paymentMethodName } });
  };

  return (
    <div className="min-h-screen py-12 px-6">
      <div className="max-w-3xl mx-auto space-y-8">
        <div className="text-center space-y-4 animate-fade-in">
          <h1 className="text-4xl font-bold">Pilih Metode Pembayaran</h1>
          <p className="text-xl text-muted-foreground">
            Total Pembayaran: <span className="font-bold text-primary">{formatPrice(total)}</span>
          </p>
        </div>

        <Card className="p-8 space-y-6 animate-scale-in">
          <h2 className="text-2xl font-bold mb-6">Metode Pembayaran</h2>
          
          <div className="grid gap-4">
            {paymentMethods.map((method) => (
              <button
                key={method.id}
                onClick={() => handlePaymentSelect(method.id)}
                className={`p-6 rounded-xl border-2 transition-all duration-300 ${
                  selectedMethod === method.id
                    ? "border-primary shadow-lg scale-105"
                    : "border-border hover:border-primary/50 hover:shadow-md"
                }`}
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-4">
                    <img 
                      src={method.logo} 
                      alt={method.name} 
                      className="w-12 h-12 object-contain rounded-lg"
                    />
                    <span className="text-lg font-semibold">{method.name}</span>
                  </div>
                  {selectedMethod === method.id && (
                    <CheckCircle className="w-6 h-6 text-primary" />
                  )}
                </div>
              </button>
            ))}
          </div>
        </Card>

        <Dialog open={showQRIS} onOpenChange={setShowQRIS}>
          <DialogContent className="max-w-md">
            <DialogHeader>
              <DialogTitle className="text-2xl font-bold text-center">Scan QRIS</DialogTitle>
            </DialogHeader>
            
            <div className="space-y-6">
              <div className="bg-white p-4 rounded-xl">
                <img
                  src={qrisImage}
                  alt="QRIS Payment"
                  className="w-full rounded-lg"
                />
              </div>

              <div className="space-y-3">
                <Button
                  onClick={handleDownloadQRIS}
                  variant="outline"
                  className="w-full"
                >
                  <Download className="mr-2 h-4 w-4" />
                  Download QRIS
                </Button>

                <Button
                  onClick={handleProceedToReceipt}
                  className="w-full bg-gradient-primary hover:opacity-90 text-white"
                >
                  Lanjut ke Struk
                </Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>
      </div>
    </div>
  );
};

export default Payment;

import { Zap, Shield, Clock, Crown, MessageCircle } from "lucide-react";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";

const Dashboard = () => {
  const features = [
    {
      icon: Zap,
      title: "Proses Cepat",
      description: "Pesanan diproses dalam hitungan menit",
    },
    {
      icon: Shield,
      title: "Aman & Terpercaya",
      description: "Garansi refill untuk semua layanan",
    },
    {
      icon: Clock,
      title: "24/7 Support",
      description: "Layanan customer support sepanjang waktu",
    },
  ];

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="relative py-20 px-6 overflow-hidden">
        <div className="absolute inset-0 bg-gradient-primary opacity-10" />
        <div className="relative max-w-4xl mx-auto text-center space-y-6 animate-fade-in">
          <h1 className="text-5xl md:text-6xl font-bold mb-6 animate-fade-in">
            Selamat Datang di{" "}
            <span className="text-primary">
              Barik Market
            </span>
          </h1>
          <p className="text-lg text-muted-foreground mb-2 animate-fade-in" style={{ animationDelay: '0.1s' }}>
            Dikelola oleh PT Lyra Group
          </p>
          <p className="text-2xl md:text-3xl font-semibold text-foreground mb-4 animate-fade-in" style={{ animationDelay: '0.2s' }}>
            Platform Social Media Marketing Profesional
          </p>
          <p className="text-lg md:text-xl text-muted-foreground max-w-3xl mx-auto leading-relaxed animate-fade-in" style={{ animationDelay: '0.4s' }}>
            Tingkatkan kehadiran digital Anda bersama PT Lyra Group. Kami menyediakan layanan berkualitas tinggi untuk TikTok, Instagram, dan Bot WhatsApp dengan proses cepat, aman, dan terpercaya. Bergabunglah dengan ribuan klien yang telah mempercayai kami untuk mengembangkan bisnis mereka.
          </p>
          <div className="mt-8 flex flex-col items-center gap-4 animate-fade-in" style={{ animationDelay: '0.6s' }}>
            <div className="flex items-center gap-2 text-muted-foreground">
              <div className="w-2 h-2 rounded-full bg-green-500 animate-pulse" />
              <span className="text-sm">Proses Otomatis & Real-time</span>
            </div>
            <a
              href="https://whatsapp.com/channel/0029Vb2cITjGufIu0CVNUj3m"
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-2 px-6 py-3 bg-green-600 hover:bg-green-700 text-white rounded-lg font-semibold transition-all duration-300 shadow-lg hover:shadow-xl animate-fade-in"
              style={{ animationDelay: '0.8s' }}
            >
              <MessageCircle className="w-5 h-5" />
              <span>Gabung Channel WhatsApp PT Lyra Group</span>
            </a>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-16 px-6">
        <div className="max-w-6xl mx-auto">
          <h2 className="text-3xl font-bold text-center mb-12">
            Mengapa Memilih Kami?
          </h2>
          <div className="grid md:grid-cols-3 gap-8">
            {features.map((feature, index) => {
              const Icon = feature.icon;
              return (
                <div
                  key={index}
                  className="p-8 rounded-2xl bg-card border border-border hover:shadow-xl transition-all duration-300 animate-fade-in"
                  style={{ animationDelay: `${index * 0.1}s` }}
                >
                  <div className="w-14 h-14 rounded-xl bg-gradient-primary flex items-center justify-center mb-4">
                    <Icon className="w-7 h-7 text-white" />
                  </div>
                  <h3 className="text-xl font-bold mb-2">{feature.title}</h3>
                  <p className="text-muted-foreground">{feature.description}</p>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* Services Overview */}
      <section className="py-16 px-6 bg-muted/30">
        <div className="max-w-6xl mx-auto">
          <h2 className="text-3xl font-bold text-center mb-12">
            Layanan Kami
          </h2>
          <div className="grid md:grid-cols-3 gap-8">
            <div className="p-8 rounded-2xl bg-card border border-border hover:shadow-xl transition-all duration-300">
              <h3 className="text-2xl font-bold mb-4 text-foreground">
                Social Media Marketing
              </h3>
              <p className="text-muted-foreground mb-4">
                Layanan boost profesional untuk TikTok dan Instagram. Tingkatkan followers, likes, dan views dengan hasil nyata dan garansi refill.
              </p>
              <ul className="space-y-2 text-sm">
                <li className="flex items-center gap-2">
                  <div className="w-1.5 h-1.5 rounded-full bg-primary" />
                  Followers Indonesia & Luar
                </li>
                <li className="flex items-center gap-2">
                  <div className="w-1.5 h-1.5 rounded-full bg-primary" />
                  Likes & Views Real
                </li>
                <li className="flex items-center gap-2">
                  <div className="w-1.5 h-1.5 rounded-full bg-primary" />
                  Garansi Refill
                </li>
              </ul>
            </div>

            <div className="p-8 rounded-2xl bg-card border border-border hover:shadow-xl transition-all duration-300">
              <h3 className="text-2xl font-bold mb-4 text-foreground">
                Sewa Bot WhatsApp
              </h3>
              <p className="text-muted-foreground mb-4">
                Bot WhatsApp multifungsi untuk membantu bisnis dan kebutuhan Anda dengan harga ekonomis.
              </p>
              <ul className="space-y-2 text-sm">
                <li className="flex items-center gap-2">
                  <div className="w-1.5 h-1.5 rounded-full bg-secondary" />
                  Paket Mulai 3 Minggu
                </li>
                <li className="flex items-center gap-2">
                  <div className="w-1.5 h-1.5 rounded-full bg-secondary" />
                  Fitur Lengkap
                </li>
                <li className="flex items-center gap-2">
                  <div className="w-1.5 h-1.5 rounded-full bg-secondary" />
                  Support 24/7
                </li>
              </ul>
            </div>

            <div className="p-8 rounded-2xl bg-card border border-primary/20 hover:shadow-xl transition-all duration-300 relative overflow-hidden">
              <div className="absolute inset-0 bg-gradient-to-br from-primary/5 to-transparent" />
              <div className="relative">
                <div className="flex items-center gap-2 mb-4">
                  <Crown className="w-6 h-6 text-primary" />
                  <h3 className="text-2xl font-bold text-foreground">
                    Premium Member
                  </h3>
                </div>
                <p className="text-muted-foreground mb-4">
                  Nikmati benefit eksklusif dengan harga sangat terjangkau, mulai dari Rp 1.000 per hari.
                </p>
                <ul className="space-y-2 text-sm">
                  <li className="flex items-center gap-2">
                    <div className="w-1.5 h-1.5 rounded-full bg-primary" />
                    Harga Mulai 1k/Hari
                  </li>
                  <li className="flex items-center gap-2">
                    <div className="w-1.5 h-1.5 rounded-full bg-primary" />
                    Akses Fitur Eksklusif
                  </li>
                  <li className="flex items-center gap-2">
                    <div className="w-1.5 h-1.5 rounded-full bg-primary" />
                    Priority Support
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* FAQ Section */}
      <section className="py-16 px-6">
        <div className="max-w-4xl mx-auto">
          <h2 className="text-3xl font-bold text-center mb-12">
            Pertanyaan yang Sering Diajukan
          </h2>
          <Accordion type="single" collapsible className="w-full space-y-4">
            <AccordionItem value="item-1" className="border border-border rounded-lg px-6 bg-card">
              <AccordionTrigger className="text-left hover:no-underline py-4">
                <span className="font-semibold text-base">Apa itu PT Lyra Group?</span>
              </AccordionTrigger>
              <AccordionContent className="text-muted-foreground pb-4">
                PT Lyra Group adalah perusahaan teknologi digital yang fokus pada solusi social media marketing dan automasi bisnis. Kami berkomitmen memberikan layanan terbaik untuk membantu individu dan bisnis berkembang di era digital.
              </AccordionContent>
            </AccordionItem>

            <AccordionItem value="item-2" className="border border-border rounded-lg px-6 bg-card">
              <AccordionTrigger className="text-left hover:no-underline py-4">
                <span className="font-semibold text-base">Kapan PT Lyra Group didirikan?</span>
              </AccordionTrigger>
              <AccordionContent className="text-muted-foreground pb-4">
                PT Lyra Group didirikan pada tanggal 8 September 2025. Sejak awal berdiri, kami terus berkembang dan berinovasi untuk memberikan solusi terbaik dalam layanan digital marketing dan automasi bisnis bagi para klien kami.
              </AccordionContent>
            </AccordionItem>

            <AccordionItem value="item-3" className="border border-border rounded-lg px-6 bg-card">
              <AccordionTrigger className="text-left hover:no-underline py-4">
                <span className="font-semibold text-base">Siapa CEO PT Lyra Group?</span>
              </AccordionTrigger>
              <AccordionContent className="text-muted-foreground pb-4">
                CEO PT Lyra Group adalah Bariklana, seorang profesional yang berpengalaman di bidang digital marketing dan teknologi. Dengan visi yang kuat, beliau memimpin perusahaan untuk menjadi platform social media marketing terdepan di Indonesia.
              </AccordionContent>
            </AccordionItem>

            <AccordionItem value="item-4" className="border border-border rounded-lg px-6 bg-card">
              <AccordionTrigger className="text-left hover:no-underline py-4">
                <span className="font-semibold text-base">Apa saja produk dan layanan yang dijual?</span>
              </AccordionTrigger>
              <AccordionContent className="text-muted-foreground pb-4">
                Kami menyediakan berbagai layanan digital: (1) Social Media Marketing untuk TikTok dan Instagram (followers, likes, views), (2) Sewa Bot WhatsApp dengan berbagai paket, (3) Premium Member dengan akses fitur eksklusif. Semua layanan dirancang untuk membantu meningkatkan performa digital Anda.
              </AccordionContent>
            </AccordionItem>

            <AccordionItem value="item-5" className="border border-border rounded-lg px-6 bg-card">
              <AccordionTrigger className="text-left hover:no-underline py-4">
                <span className="font-semibold text-base">Bagaimana asal usul Barik Market?</span>
              </AccordionTrigger>
              <AccordionContent className="text-muted-foreground pb-4">
                Barik Market adalah platform marketplace dari PT Lyra Group yang diciptakan untuk memudahkan akses layanan social media marketing. Nama "Barik" terinspirasi dari bahasa Jawa yang berarti "cepat", mencerminkan komitmen kami memberikan layanan yang cepat, efisien, dan terpercaya untuk semua kalangan.
              </AccordionContent>
            </AccordionItem>

            <AccordionItem value="item-6" className="border border-border rounded-lg px-6 bg-card">
              <AccordionTrigger className="text-left hover:no-underline py-4">
                <span className="font-semibold text-base">Apakah layanan social media marketing aman?</span>
              </AccordionTrigger>
              <AccordionContent className="text-muted-foreground pb-4">
                Ya, 100% aman. Kami menggunakan metode yang sesuai dengan ketentuan platform dan memberikan garansi refill untuk memastikan kepuasan pelanggan. Semua proses dilakukan dengan sistem otomatis yang aman dan terpercaya.
              </AccordionContent>
            </AccordionItem>

            <AccordionItem value="item-7" className="border border-border rounded-lg px-6 bg-card">
              <AccordionTrigger className="text-left hover:no-underline py-4">
                <span className="font-semibold text-base">Berapa lama proses pengerjaan pesanan?</span>
              </AccordionTrigger>
              <AccordionContent className="text-muted-foreground pb-4">
                Proses dimulai secara otomatis setelah pembayaran dikonfirmasi. Waktu penyelesaian bervariasi tergantung jenis layanan, biasanya antara beberapa menit hingga 24 jam. Untuk layanan bot WhatsApp, aktivasi dilakukan maksimal 1x24 jam.
              </AccordionContent>
            </AccordionItem>

            <AccordionItem value="item-8" className="border border-border rounded-lg px-6 bg-card">
              <AccordionTrigger className="text-left hover:no-underline py-4">
                <span className="font-semibold text-base">Apakah ada garansi untuk layanan yang dibeli?</span>
              </AccordionTrigger>
              <AccordionContent className="text-muted-foreground pb-4">
                Tentu! Kami menyediakan garansi refill untuk semua layanan followers dan likes. Jika terjadi penurunan dalam periode tertentu, kami akan menggantinya secara gratis. Untuk sewa bot, kami juga memberikan support penuh selama masa sewa berlangsung.
              </AccordionContent>
            </AccordionItem>

            <AccordionItem value="item-9" className="border border-border rounded-lg px-6 bg-card">
              <AccordionTrigger className="text-left hover:no-underline py-4">
                <span className="font-semibold text-base">Bagaimana cara menghubungi customer support?</span>
              </AccordionTrigger>
              <AccordionContent className="text-muted-foreground pb-4">
                Kami menyediakan layanan customer support 24/7 melalui berbagai channel: WhatsApp admin, email, dan channel WhatsApp resmi PT Lyra Group. Tim kami siap membantu menjawab pertanyaan dan menyelesaikan kendala Anda kapan saja.
              </AccordionContent>
            </AccordionItem>
          </Accordion>
        </div>
      </section>
    </div>
  );
};

export default Dashboard;

import { useState } from "react";
import { Link } from "react-router-dom";
import { Card } from "@/components/ui/card";
import { Avatar } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Star, Quote, Heart, MessageCircle, Send } from "lucide-react";
import { toast } from "sonner";

const Testimonials = () => {
  const [testimonials, setTestimonials] = useState([
    {
      id: 1,
      name: "Rina Kusuma",
      role: "Content Creator",
      image: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150&h=150&fit=crop",
      rating: 5,
      text: "Pelayanan sangat memuaskan! Followers TikTok saya naik drastis dalam waktu singkat. Prosesnya cepat dan hasilnya real. Sangat recommended untuk yang mau boost akun sosmed!",
      service: "TikTok Followers",
      date: "2 hari yang lalu",
      likes: 45,
      comments: [
        { name: "Dimas P.", text: "Sama sis! Aku juga puas banget pakai layanan ini" },
        { name: "Siti N.", text: "Followers aku juga nambah cepet banget!" }
      ]
    },
    {
      id: 2,
      name: "Dimas Pratama",
      role: "Online Shop Owner",
      image: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&h=150&fit=crop",
      rating: 5,
      text: "Bot WhatsApp yang disewakan sangat membantu bisnis saya. Fiturnya lengkap dan support dari tim Barik Market sangat responsif. Worth it banget!",
      service: "Bot WhatsApp",
      date: "5 hari yang lalu",
      likes: 32,
      comments: [
        { name: "Arif B.", text: "Bot nya bisa custom sesuai kebutuhan ga?" }
      ]
    },
    {
      id: 3,
      name: "Siti Nurhaliza",
      role: "Influencer",
      image: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=150&h=150&fit=crop",
      rating: 5,
      text: "Instagram likes dan followers bertambah dengan natural. Tidak terlihat fake sama sekali. Harganya juga sangat terjangkau. Terima kasih Barik Market!",
      service: "Instagram Package",
      date: "1 minggu yang lalu",
      likes: 28,
      comments: []
    },
    {
      id: 4,
      name: "Arif Budiman",
      role: "Digital Marketer",
      image: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=150&h=150&fit=crop",
      rating: 5,
      text: "Sudah berlangganan 3 bulan untuk beberapa akun klien. Hasilnya konsisten dan customer service nya ramah. Pasti akan order lagi!",
      service: "TikTok & IG Bundle",
      date: "2 minggu yang lalu",
      likes: 56,
      comments: [
        { name: "Maya S.", text: "Wah boleh dong share tips manage banyak akun" },
        { name: "Budi S.", text: "CS nya emang ramah banget ya!" }
      ]
    },
    {
      id: 5,
      name: "Maya Safitri",
      role: "Beauty Vlogger",
      image: "https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=150&h=150&fit=crop",
      rating: 5,
      text: "Views TikTok saya tembus jutaan! Engagement rate juga meningkat signifikan. Barik Market memang yang terbaik untuk boost sosial media.",
      service: "TikTok Views",
      date: "3 minggu yang lalu",
      likes: 89,
      comments: [
        { name: "Dewi L.", text: "Kontennya apa kak? Pengen juga viral hehe" }
      ]
    },
    {
      id: 6,
      name: "Budi Santoso",
      role: "Entrepreneur",
      image: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=150&h=150&fit=crop",
      rating: 5,
      text: "Pelayanan profesional dan hasil yang memuaskan. Tim support sangat membantu dalam menjelaskan setiap detail layanan. Highly recommended!",
      service: "Full Package",
      date: "1 bulan yang lalu",
      likes: 23,
      comments: []
    },
    {
      id: 7,
      name: "Dewi Lestari",
      role: "Fashion Blogger",
      image: "https://images.unsplash.com/photo-1489424731084-a5d8b219a5bb?w=150&h=150&fit=crop",
      rating: 5,
      text: "Awalnya ragu, tapi setelah coba ternyata hasilnya luar biasa! Followers Instagram saya bertambah dan engagement juga naik. Thank you!",
      service: "Instagram Followers",
      date: "1 bulan yang lalu",
      likes: 41,
      comments: [
        { name: "Fajar R.", text: "Sama! Awalnya skeptis tapi ternyata worth it" }
      ]
    },
    {
      id: 8,
      name: "Fajar Ramadhan",
      role: "Musician",
      image: "https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?w=150&h=150&fit=crop",
      rating: 5,
      text: "Konten musik saya jadi lebih dilihat banyak orang. Views dan likes meningkat pesat. Barik Market memang solusi terbaik untuk promosi digital!",
      service: "TikTok Likes & Views",
      date: "5 minggu yang lalu",
      likes: 67,
      comments: [
        { name: "Putri A.", text: "Musiknya genre apa kak?" }
      ]
    },
    {
      id: 9,
      name: "Putri Andini",
      role: "Food Blogger",
      image: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&h=150&fit=crop",
      rating: 5,
      text: "Konten kuliner saya makin banyak yang lihat! Followers Instagram naik 10K dalam sebulan. Pelayanannya cepat dan hasilnya sangat natural. Recommended!",
      service: "Instagram Followers",
      date: "3 hari yang lalu",
      likes: 52,
      comments: []
    },
    {
      id: 10,
      name: "Rizky Maulana",
      role: "Gaming Streamer",
      image: "https://images.unsplash.com/photo-1599566150163-29194dcaad36?w=150&h=150&fit=crop",
      rating: 5,
      text: "Konten gaming saya di TikTok jadi viral! Views dan engagement meningkat drastis. Barik Market benar-benar membantu channel saya berkembang pesat.",
      service: "TikTok Views",
      date: "1 minggu yang lalu",
      likes: 74,
      comments: [
        { name: "Amanda C.", text: "Main game apa kak?" }
      ]
    },
    {
      id: 11,
      name: "Amanda Chen",
      role: "Lifestyle Influencer",
      image: "https://images.unsplash.com/photo-1517841905240-472988babdf9?w=150&h=150&fit=crop",
      rating: 5,
      text: "Amazing service! The growth is organic and consistent. My Instagram engagement has doubled in just weeks. Great investment for content creators!",
      service: "Instagram Package",
      date: "4 hari yang lalu",
      likes: 38,
      comments: []
    },
    {
      id: 12,
      name: "Wahyu Setiawan",
      role: "Photographer",
      image: "https://images.unsplash.com/photo-1492562080023-ab3db95bfbce?w=150&h=150&fit=crop",
      rating: 5,
      text: "Portofolio fotografi saya makin dilirik klien potensial berkat boost dari Barik Market. Followers bertambah dan banyak yang DM untuk booking. Mantap!",
      service: "Instagram Followers & Likes",
      date: "2 minggu yang lalu",
      likes: 61,
      comments: [
        { name: "Sarah J.", text: "Boleh liat portfolionya?" }
      ]
    },
    {
      id: 13,
      name: "Sarah Johnson",
      role: "Travel Blogger",
      image: "https://images.unsplash.com/photo-1524504388940-b1c1722653e1?w=150&h=150&fit=crop",
      rating: 5,
      text: "Perfect for growing my travel content! The followers are real and engagement is great. Barik Market helped me reach 50K followers milestone!",
      service: "TikTok & IG Bundle",
      date: "1 minggu yang lalu",
      likes: 95,
      comments: [
        { name: "Indra W.", text: "Congrats on 50K!" },
        { name: "Lina M.", text: "Travel kemana aja kak?" }
      ]
    },
    {
      id: 14,
      name: "Indra Wijaya",
      role: "Fitness Coach",
      image: "https://images.unsplash.com/photo-1568602471122-7832951cc4c5?w=150&h=150&fit=crop",
      rating: 5,
      text: "Program fitness saya makin banyak peminat! Followers Instagram naik signifikan dan banyak yang tertarik join kelas online. Terima kasih Barik Market!",
      service: "Instagram Followers",
      date: "10 hari yang lalu",
      likes: 44,
      comments: []
    },
    {
      id: 15,
      name: "Lina Maharani",
      role: "Makeup Artist",
      image: "https://images.unsplash.com/photo-1487412720507-e7ab37603c6f?w=150&h=150&fit=crop",
      rating: 5,
      text: "Tutorial makeup saya jadi trending di TikTok! Views meningkat pesat dan banyak brand yang approach untuk kolaborasi. Barik Market the best!",
      service: "TikTok Views & Likes",
      date: "5 hari yang lalu",
      likes: 82,
      comments: [
        { name: "David M.", text: "Brand mana aja yang reach out?" }
      ]
    },
    {
      id: 16,
      name: "David Martinez",
      role: "Tech Reviewer",
      image: "https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?w=150&h=150&fit=crop",
      rating: 5,
      text: "Excellent service for tech content creators! My reviews reach more people now. The growth is steady and authentic. Highly recommend Barik Market!",
      service: "TikTok Followers",
      date: "1 minggu yang lalu",
      likes: 29,
      comments: []
    },
    {
      id: 17,
      name: "Ayu Lestari",
      role: "Fashion Designer",
      image: "https://images.unsplash.com/photo-1531746020798-e6953c6e8e04?w=150&h=150&fit=crop",
      rating: 5,
      text: "Brand fashion saya makin dikenal! Instagram followers dan engagement meningkat, penjualan produk juga naik. Investasi terbaik untuk bisnis online!",
      service: "Instagram Package",
      date: "2 minggu yang lalu",
      likes: 58,
      comments: [
        { name: "Hendra K.", text: "Boleh tau brandnya?" }
      ]
    },
    {
      id: 18,
      name: "Hendra Kusuma",
      role: "Business Consultant",
      image: "https://images.unsplash.com/photo-1556157382-97eda2d62296?w=150&h=150&fit=crop",
      rating: 5,
      text: "Konten edukasi bisnis saya jadi lebih banyak yang tertarik! Bot WhatsApp juga sangat membantu untuk handle inquiry dari calon klien. Top service!",
      service: "Bot WhatsApp",
      date: "3 minggu yang lalu",
      likes: 36,
      comments: []
    },
    {
      id: 19,
      name: "Mega Puspita",
      role: "Culinary Entrepreneur",
      image: "https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=150&h=150&fit=crop",
      rating: 5,
      text: "Bisnis kuliner saya berkembang pesat berkat social media boost dari Barik Market. Followers bertambah banyak dan orderan juga meningkat. Recommended!",
      service: "Full Package",
      date: "1 minggu yang lalu",
      likes: 71,
      comments: [
        { name: "Kevin T.", text: "Bisnisnya dimana kak?" }
      ]
    },
    {
      id: 20,
      name: "Kevin Tan",
      role: "E-commerce Owner",
      image: "https://images.unsplash.com/photo-1539571696357-5a69c17a67c6?w=150&h=150&fit=crop",
      rating: 5,
      text: "Great results for my online store! Instagram followers grew fast and sales increased significantly. The WhatsApp bot is also super helpful. Worth every penny!",
      service: "Instagram & Bot Package",
      date: "4 hari yang lalu",
      likes: 47,
      comments: []
    }
  ]);

  const [likedTestimonials, setLikedTestimonials] = useState<Set<number>>(new Set());
  const [showCommentInput, setShowCommentInput] = useState<number | null>(null);
  const [commentText, setCommentText] = useState("");
  const [commentName, setCommentName] = useState("");

  const handleLike = (id: number) => {
    if (likedTestimonials.has(id)) {
      toast.error("Anda sudah memberikan like pada testimoni ini!");
      return;
    }
    
    setTestimonials(prev => prev.map(t => 
      t.id === id ? { ...t, likes: t.likes + 1 } : t
    ));
    setLikedTestimonials(prev => new Set(prev).add(id));
    toast.success("Like berhasil ditambahkan!");
  };

  const handleAddComment = (id: number) => {
    if (!commentName.trim() || !commentText.trim()) {
      toast.error("Nama dan komentar tidak boleh kosong!");
      return;
    }

    setTestimonials(prev => prev.map(t => 
      t.id === id ? { 
        ...t, 
        comments: [...t.comments, { name: commentName, text: commentText }] 
      } : t
    ));
    
    setCommentText("");
    setCommentName("");
    setShowCommentInput(null);
    toast.success("Komentar berhasil ditambahkan!");
  };

  return (
    <div className="min-h-screen py-8 md:py-12 px-4 md:px-6">
      <div className="max-w-7xl mx-auto space-y-8 md:space-y-12">
        {/* Header */}
        <div className="text-center space-y-4 animate-fade-in">
          <h1 className="text-3xl md:text-5xl font-bold">
            Testimoni Pelanggan
          </h1>
          <p className="text-lg md:text-xl text-muted-foreground max-w-2xl mx-auto">
            Apa kata mereka yang telah menggunakan layanan kami
          </p>
          <div className="flex items-center justify-center gap-2 pt-2">
            <div className="flex">
              {[...Array(5)].map((_, i) => (
                <Star key={i} className="w-6 h-6 fill-yellow-400 text-yellow-400" />
              ))}
            </div>
            <span className="text-lg font-semibold">5.0</span>
            <span className="text-muted-foreground">dari {testimonials.length} ulasan</span>
          </div>
        </div>

        {/* Testimonials Grid */}
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6 md:gap-8">
          {testimonials.map((testimonial, index) => (
            <div
              key={testimonial.id}
              className="bg-card rounded-2xl p-6 border border-border shadow-lg hover:shadow-xl transition-all duration-300 hover:-translate-y-1 animate-fade-in"
              style={{ animationDelay: `${index * 0.1}s` }}
            >
              <div className="space-y-4">
                {/* Header */}
                <div className="flex items-start justify-between">
                  <div className="flex items-center gap-3">
                    <img
                      src={testimonial.image}
                      alt={testimonial.name}
                      className="w-12 h-12 rounded-full object-cover border-2 border-primary/20"
                    />
                    <div>
                      <h3 className="font-bold text-foreground">{testimonial.name}</h3>
                      <p className="text-sm text-muted-foreground">{testimonial.role}</p>
                    </div>
                  </div>
                  <Quote className="w-8 h-8 text-primary/20" />
                </div>

                {/* Rating */}
                <div className="flex items-center gap-1">
                  {[...Array(testimonial.rating)].map((_, i) => (
                    <Star key={i} className="w-4 h-4 fill-yellow-400 text-yellow-400" />
                  ))}
                </div>

                {/* Content */}
                <p className="text-muted-foreground leading-relaxed">
                  {testimonial.text}
                </p>

                {/* Footer */}
                <div className="pt-4 border-t border-border space-y-3">
                  <div className="flex items-center justify-between text-xs text-muted-foreground">
                    <span className="font-medium text-primary">{testimonial.service}</span>
                    <span>{testimonial.date}</span>
                  </div>

                  {/* Like and Comment Section */}
                  <div className="flex items-center gap-4 pt-2">
                    <button 
                      onClick={() => handleLike(testimonial.id)}
                      className={`flex items-center gap-1.5 text-sm transition-colors group ${
                        likedTestimonials.has(testimonial.id) 
                          ? "text-primary cursor-not-allowed" 
                          : "text-muted-foreground hover:text-primary"
                      }`}
                      disabled={likedTestimonials.has(testimonial.id)}
                    >
                      <Heart className={`w-4 h-4 transition-all ${
                        likedTestimonials.has(testimonial.id) 
                          ? "fill-primary text-primary" 
                          : "group-hover:fill-primary group-hover:text-primary"
                      }`} />
                      <span className="font-medium">{testimonial.likes}</span>
                    </button>
                    <button
                      onClick={() => setShowCommentInput(showCommentInput === testimonial.id ? null : testimonial.id)}
                      className="flex items-center gap-1.5 text-sm text-muted-foreground hover:text-primary transition-colors"
                    >
                      <MessageCircle className="w-4 h-4" />
                      <span className="font-medium">{testimonial.comments.length}</span>
                    </button>
                  </div>

                  {/* Comment Input */}
                  {showCommentInput === testimonial.id && (
                    <div className="space-y-2 pt-3 border-t border-border animate-fade-in">
                      <Input
                        placeholder="Nama Anda"
                        value={commentName}
                        onChange={(e) => setCommentName(e.target.value)}
                        className="text-sm"
                      />
                      <div className="flex gap-2">
                        <Input
                          placeholder="Tulis komentar..."
                          value={commentText}
                          onChange={(e) => setCommentText(e.target.value)}
                          className="text-sm"
                          onKeyPress={(e) => {
                            if (e.key === 'Enter') {
                              handleAddComment(testimonial.id);
                            }
                          }}
                        />
                        <Button
                          onClick={() => handleAddComment(testimonial.id)}
                          size="sm"
                          className="bg-gradient-primary text-white"
                        >
                          <Send className="w-4 h-4" />
                        </Button>
                      </div>
                    </div>
                  )}

                  {/* Comments */}
                  {testimonial.comments.length > 0 && (
                    <div className="space-y-2 pt-2">
                      {testimonial.comments.map((comment, idx) => (
                        <div key={idx} className="bg-muted/30 rounded-lg p-2.5 text-xs animate-fade-in">
                          <span className="font-semibold text-foreground">{comment.name}</span>
                          <span className="text-muted-foreground"> {comment.text}</span>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* CTA Section */}
        <div className="bg-gradient-primary rounded-3xl p-8 md:p-12 text-center text-white space-y-4 animate-fade-in">
          <h2 className="text-2xl md:text-4xl font-bold">
            Bergabunglah dengan Ribuan Pelanggan Puas
          </h2>
          <p className="text-lg text-white/90 max-w-2xl mx-auto">
            Tingkatkan presence digital Anda sekarang dan rasakan perbedaannya
          </p>
          <div className="pt-4">
            <Link to="/order">
              <button className="bg-white text-primary px-8 py-4 rounded-xl font-bold text-lg hover:bg-white/90 transition-all duration-300 hover:scale-105 shadow-lg">
                Mulai Sekarang
              </button>
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Testimonials;

import { tiktokPricing, instagramPricing, whatsappPricing, facebookPricing, botRentalPricing, premiumMemberPricing } from "@/data/pricing";
import { Button } from "@/components/ui/button";
import { Link } from "react-router-dom";
import { Instagram, Music, Crown, MessageCircle, Facebook } from "lucide-react";

const Services = () => {
  const formatPrice = (price: number) => {
    return new Intl.NumberFormat("id-ID", {
      style: "currency",
      currency: "IDR",
      minimumFractionDigits: 0,
    }).format(price);
  };

  return (
    <div className="min-h-screen py-8 md:py-12 px-4 md:px-6">
      <div className="max-w-7xl mx-auto space-y-12">
        {/* Header */}
        <div className="text-center space-y-4 animate-fade-in">
          <h1 className="text-3xl md:text-5xl font-bold">
            Layanan & Harga
          </h1>
          <p className="text-lg md:text-xl text-muted-foreground">
            Pilih paket yang sesuai dengan kebutuhan Anda
          </p>
        </div>


        {/* TikTok Services */}
        <section className="space-y-6 animate-fade-in">
          <div className="bg-card rounded-3xl p-6 md:p-10 border-2 border-primary/20 shadow-xl">
            <div className="flex items-center justify-center gap-3 mb-8">
              <div className="w-12 h-12 rounded-2xl bg-gradient-primary flex items-center justify-center">
                <Music className="w-7 h-7 text-white" />
              </div>
              <h2 className="text-3xl md:text-4xl font-bold text-foreground">
                TIKTOK
              </h2>
            </div>

            <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4 md:gap-6">
              <ServiceCard title="Followers Luar" items={tiktokPricing.followersLuar} formatPrice={formatPrice} />
              <ServiceCard title="Followers Indo" items={tiktokPricing.followersIndo} formatPrice={formatPrice} />
              <ServiceCard title="Likes" items={tiktokPricing.likes} formatPrice={formatPrice} />
              <ServiceCard title="Views" items={tiktokPricing.views} formatPrice={formatPrice} />
            </div>
          </div>
        </section>

        {/* Instagram Services */}
        <section className="space-y-6 animate-fade-in">
          <div className="bg-card rounded-3xl p-6 md:p-10 border-2 border-primary/20 shadow-xl">
            <div className="flex items-center justify-center gap-3 mb-8">
              <div className="w-12 h-12 rounded-2xl bg-gradient-primary flex items-center justify-center">
                <Instagram className="w-7 h-7 text-white" />
              </div>
              <h2 className="text-3xl md:text-4xl font-bold text-foreground">
                INSTAGRAM
              </h2>
            </div>

            <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4 md:gap-6">
              <ServiceCard title="Followers Luar" items={instagramPricing.followersLuar} formatPrice={formatPrice} />
              <ServiceCard title="Followers Indo" items={instagramPricing.followersIndo} formatPrice={formatPrice} />
              <ServiceCard title="Likes" items={instagramPricing.likes} formatPrice={formatPrice} />
              <ServiceCard title="Views" items={instagramPricing.views} formatPrice={formatPrice} />
            </div>
          </div>
        </section>

        {/* WhatsApp Services */}
        <section className="space-y-6 animate-fade-in">
          <div className="bg-card rounded-3xl p-6 md:p-10 border-2 border-primary/20 shadow-xl">
            <div className="flex items-center justify-center gap-3 mb-8">
              <div className="w-12 h-12 rounded-2xl bg-gradient-primary flex items-center justify-center">
                <MessageCircle className="w-7 h-7 text-white" />
              </div>
              <h2 className="text-3xl md:text-4xl font-bold text-foreground">
                WHATSAPP
              </h2>
            </div>

            <div className="grid sm:grid-cols-2 gap-4 md:gap-6">
              <ServiceCard title="Channel Member" items={whatsappPricing.channelMember} formatPrice={formatPrice} />
              <ServiceCard title="Reaction" items={whatsappPricing.reaction} formatPrice={formatPrice} />
            </div>
          </div>
        </section>

        {/* Facebook Services */}
        <section className="space-y-6 animate-fade-in">
          <div className="bg-card rounded-3xl p-6 md:p-10 border-2 border-primary/20 shadow-xl">
            <div className="flex items-center justify-center gap-3 mb-8">
              <div className="w-12 h-12 rounded-2xl bg-gradient-primary flex items-center justify-center">
                <Facebook className="w-7 h-7 text-white" />
              </div>
              <h2 className="text-3xl md:text-4xl font-bold text-foreground">
                FACEBOOK
              </h2>
            </div>

            <div className="grid sm:grid-cols-2 lg:grid-cols-5 gap-4 md:gap-6">
              <ServiceCard title="Follow Luar" items={facebookPricing.followersLuar} formatPrice={formatPrice} />
              <ServiceCard title="Follow Indo" items={facebookPricing.followersIndo} formatPrice={formatPrice} />
              <ServiceCard title="Group Member" items={facebookPricing.groupMember} formatPrice={formatPrice} />
              <ServiceCard title="Likes Post" items={facebookPricing.likes} formatPrice={formatPrice} />
              <ServiceCard title="View Video" items={facebookPricing.views} formatPrice={formatPrice} />
            </div>
          </div>
        </section>

        {/* Bot Rental */}
        <section className="space-y-6 animate-fade-in">
          <div className="bg-card rounded-3xl p-6 md:p-10 border-2 border-secondary/20 shadow-xl">
            <h2 className="text-3xl md:text-4xl font-bold text-center mb-8 text-foreground">
              Sewa Bot Lyra Assistant
            </h2>

            <div className="grid md:grid-cols-3 gap-6">
              {/* Premium Member Package */}
              <div className="space-y-4">
                <h3 className="text-lg font-bold text-center pb-3 border-b border-border">
                  Paket Sewa + Premium Member
                </h3>
                <p className="text-sm text-muted-foreground text-center">1 User</p>
                {botRentalPricing.premiumMember.map((item, index) => (
                  <div
                    key={index}
                    className="flex items-center justify-between p-4 rounded-xl bg-muted/50 hover:bg-muted hover:shadow-md transition-all duration-300"
                  >
                    <span className="font-semibold">{item.duration}</span>
                    <span className="font-bold text-primary">{formatPrice(item.price)}</span>
                  </div>
                ))}
              </div>

              {/* Premium All Admin Package */}
              <div className="space-y-4">
                <h3 className="text-lg font-bold text-center pb-3 border-b border-border">
                  Paket Sewa + Premium All Admin
                </h3>
                <p className="text-sm text-muted-foreground text-center">Maks. 5 Admin</p>
                {botRentalPricing.premiumAllAdmin.map((item, index) => (
                  <div
                    key={index}
                    className="flex items-center justify-between p-4 rounded-xl bg-muted/50 hover:bg-muted hover:shadow-md transition-all duration-300"
                  >
                    <span className="font-semibold">{item.duration}</span>
                    <span className="font-bold text-primary">{formatPrice(item.price)}</span>
                  </div>
                ))}
              </div>

            </div>

            <p className="text-sm text-muted-foreground text-center pt-6 mt-6 border-t border-border">
              Tidak melayani sewa permanen karena sistem bot dapat mengalami pembaruan atau penghentian layanan sewaktu-waktu
            </p>
          </div>
        </section>

        {/* Premium Member */}
        <section className="space-y-6 animate-fade-in">
          <div className="bg-card rounded-3xl p-6 md:p-10 border-2 border-primary/30 shadow-xl relative overflow-hidden">
            <div className="absolute inset-0 bg-gradient-to-br from-primary/5 to-transparent" />
            <div className="relative">
              <div className="flex items-center justify-center gap-3 mb-8">
                <div className="w-12 h-12 rounded-2xl bg-gradient-primary flex items-center justify-center">
                  <Crown className="w-7 h-7 text-white" />
                </div>
                <h2 className="text-3xl md:text-4xl font-bold text-foreground">
                  Premium Member
                </h2>
              </div>

              <div className="max-w-4xl mx-auto">
                <div className="text-center mb-6">
                  <p className="text-lg text-muted-foreground mb-2">
                    💎 Nikmati benefit eksklusif dengan harga terjangkau
                  </p>
                  <p className="text-2xl font-bold text-primary">
                    Rp 1.000 / Hari
                  </p>
                </div>

                <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-5 gap-3 mt-8">
                  {premiumMemberPricing.slice(0, 15).map((item) => (
                    <div
                      key={item.days}
                      className="p-4 rounded-xl bg-gradient-to-br from-primary/10 to-primary/5 border border-primary/20 hover:shadow-lg hover:scale-105 transition-all duration-300"
                    >
                      <div className="text-center">
                        <div className="text-2xl font-bold text-primary mb-1">
                          {item.days}
                        </div>
                        <div className="text-xs text-muted-foreground mb-2">
                          Hari
                        </div>
                        <div className="text-sm font-semibold">
                          {formatPrice(item.price)}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>

                <div className="mt-6 p-4 rounded-xl bg-muted/50 border border-border">
                  <p className="text-sm text-muted-foreground text-center">
                    → Tersedia hingga 30 hari | Akses benefit eksklusif | Priority support
                  </p>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* CTA */}
        <div className="text-center pt-8 animate-fade-in">
          <Link to="/order">
            <Button size="lg" className="bg-gradient-primary hover:opacity-90 text-white shadow-lg text-lg px-8 py-6 rounded-xl transition-all duration-300 hover:scale-105">
              Buat Pesanan Sekarang
            </Button>
          </Link>
        </div>
      </div>
    </div>
  );
};

const ServiceCard = ({ 
  title, 
  items, 
  formatPrice 
}: { 
  title: string; 
  items: { quantity: number; price: number }[];
  formatPrice: (price: number) => string;
}) => {
  return (
    <div className="bg-background rounded-2xl p-5 md:p-6 border border-border shadow-md hover:shadow-xl transition-all duration-300 hover:-translate-y-1">
      <h3 className="text-base md:text-lg font-bold text-center mb-4 pb-4 border-b border-border">
        {title}
      </h3>
      <div className="space-y-2.5">
        {items.map((item, index) => (
          <div
            key={index}
            className="flex items-center justify-between text-sm hover:bg-muted/50 p-2.5 rounded-lg transition-all duration-200"
          >
            <span className="font-medium">{item.quantity.toLocaleString()}</span>
            <span className="font-semibold text-primary">{formatPrice(item.price)}</span>
          </div>
        ))}
      </div>
    </div>
  );
};

export default Services;

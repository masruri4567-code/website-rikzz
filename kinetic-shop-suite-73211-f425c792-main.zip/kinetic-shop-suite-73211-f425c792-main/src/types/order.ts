export interface SocialMediaService {
  platform: "tiktok" | "instagram" | "whatsapp" | "facebook";
  category: string;
  quantity: number;
  price: number;
}

export interface BotRentalService {
  duration: string;
  price: number;
  package?: string;
}

export interface PremiumMemberService {
  days: number;
  price: number;
}

export interface OrderItem {
  id: string;
  type: "social-media" | "bot-rental" | "premium-member";
  name: string;
  link?: string;
  service: SocialMediaService | BotRentalService | PremiumMemberService;
}

export interface Order {
  id: string;
  items: OrderItem[];
  total: number;
  date: string;
  status: "pending" | "completed";
}

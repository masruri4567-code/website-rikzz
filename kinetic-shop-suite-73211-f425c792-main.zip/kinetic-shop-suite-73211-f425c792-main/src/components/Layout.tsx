import { useState } from "react";
import { Menu } from "lucide-react";
import Sidebar from "./Sidebar";
import ThemeToggle from "./ThemeToggle";

interface LayoutProps {
  children: React.ReactNode;
}

const Layout = ({ children }: LayoutProps) => {
  const [sidebarOpen, setSidebarOpen] = useState(false);

  return (
    <div className="min-h-screen bg-background">
      <Sidebar isOpen={sidebarOpen} onClose={() => setSidebarOpen(false)} />
      
      {/* Header */}
      <header className="sticky top-0 z-30 bg-card/80 backdrop-blur-lg border-b border-border shadow-sm">
        <div className="container mx-auto px-6 py-5 flex items-center justify-between">
          <div className="flex items-center gap-4">
            <button
              onClick={() => setSidebarOpen(true)}
              className="p-2.5 hover:bg-primary/10 rounded-xl transition-all duration-300 hover:scale-105"
              aria-label="Open menu"
            >
              <Menu className="w-6 h-6 text-primary" />
            </button>
            <h1 className="text-2xl md:text-3xl font-bold text-foreground tracking-tight">
              Barik Market
            </h1>
          </div>

          <ThemeToggle />
        </div>
      </header>

      {/* Main Content */}
      <main className="container mx-auto">
        {children}
      </main>

      {/* Footer */}
      <footer className="bg-card border-t border-border mt-20">
        <div className="container mx-auto px-6 py-6">
          <div className="flex flex-col md:flex-row justify-between items-center gap-4">
            <div className="text-center md:text-left">
              <p className="font-bold text-foreground">Barik Market</p>
              <p className="text-xs text-muted-foreground">PT Lyra Group</p>
            </div>
            
            <div className="text-center md:text-right">
              <p className="text-xs text-muted-foreground">
                2024 All rights reserved
              </p>
              <p className="text-xs text-muted-foreground">
                Developed by Bariklana Developer
              </p>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default Layout;

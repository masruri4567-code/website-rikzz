import { X, Home, ShoppingBag, Receipt, MessageSquare, Mail } from "lucide-react";
import { Link, useLocation } from "react-router-dom";

interface SidebarProps {
  isOpen: boolean;
  onClose: () => void;
}

const Sidebar = ({ isOpen, onClose }: SidebarProps) => {
  const location = useLocation();

  const menuItems = [
    { icon: Home, label: "Beranda", path: "/" },
    { icon: ShoppingBag, label: "Layanan", path: "/services" },
    { icon: Receipt, label: "Buat Pesanan", path: "/order" },
    { icon: MessageSquare, label: "Testimoni", path: "/testimonials" },
    { icon: Mail, label: "Contact Us", path: "/contact" },
  ];

  return (
    <>
      {/* Overlay */}
      <div
        className={`fixed inset-0 bg-black/50 backdrop-blur-sm z-40 transition-opacity duration-300 ${
          isOpen ? "opacity-100" : "opacity-0 pointer-events-none"
        }`}
        onClick={onClose}
      />

      {/* Sidebar */}
      <aside
        className={`fixed top-0 left-0 h-full w-80 bg-card border-r border-border z-50 transition-transform duration-300 ease-out ${
          isOpen ? "translate-x-0" : "-translate-x-full"
        } overflow-y-auto`}
      >
        {/* Header */}
        <div className="sticky top-0 bg-card/95 backdrop-blur-sm border-b border-border p-6 flex items-center justify-between">
          <h2 className="text-2xl font-bold text-foreground tracking-tight">
            Barik Market
          </h2>
          <button
            onClick={onClose}
            className="p-2 hover:bg-primary/10 rounded-xl transition-all duration-300 hover:scale-105"
            aria-label="Close menu"
          >
            <X className="w-6 h-6 text-primary" />
          </button>
        </div>

        {/* Menu Items */}
        <nav className="p-4 space-y-2">
          {menuItems.map((item) => {
            const Icon = item.icon;
            const isActive = location.pathname === item.path;
            return (
              <Link
                key={item.path}
                to={item.path}
                onClick={onClose}
                className={`flex items-center gap-3 px-4 py-3 rounded-xl transition-all duration-200 ${
                  isActive
                    ? "bg-gradient-primary text-white shadow-lg"
                    : "hover:bg-muted"
                }`}
              >
                <Icon className="w-5 h-5" />
                <span className="font-medium">{item.label}</span>
              </Link>
            );
          })}
        </nav>

        {/* Footer */}
        <div className="sticky bottom-0 bg-card/95 backdrop-blur-sm border-t border-border p-4">
          <p className="text-xs text-center text-muted-foreground">
            2024 Barik Market - PT Lyra Group
          </p>
        </div>
      </aside>
    </>
  );
};

export default Sidebar;

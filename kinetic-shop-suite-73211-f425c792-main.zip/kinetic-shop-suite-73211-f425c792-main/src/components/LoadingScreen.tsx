import { useEffect, useState } from "react";

const LoadingScreen = ({ onLoadingComplete }: { onLoadingComplete: () => void }) => {
  const [progress, setProgress] = useState(0);

  useEffect(() => {
    // 4 seconds = 4000ms, update every 40ms for smooth animation
    const duration = 4000;
    const interval = 40;
    const increment = (100 / duration) * interval;
    
    const timer = setInterval(() => {
      setProgress((prev) => {
        if (prev >= 100) {
          clearInterval(timer);
          setTimeout(onLoadingComplete, 300);
          return 100;
        }
        return Math.min(prev + increment, 100);
      });
    }, interval);

    return () => clearInterval(timer);
  }, [onLoadingComplete]);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-background">
      <div className="text-center space-y-12 px-6 max-w-md mx-auto">
        <div className="animate-scale-in space-y-4">
          <h1 className="text-5xl md:text-6xl font-bold text-foreground tracking-tight">
            Barik Market
          </h1>
          <p className="text-lg text-muted-foreground">
            Platform Social Media Marketing Profesional
          </p>
          <p className="text-sm text-muted-foreground">
            PT Lyra Group
          </p>
        </div>
        
        <div className="w-full space-y-4">
          {/* Modern Loading Bar */}
          <div className="relative h-1.5 bg-muted/30 rounded-full overflow-hidden">
            <div 
              className="absolute inset-0 h-full bg-gradient-to-r from-primary via-primary/80 to-primary rounded-full transition-all duration-200 ease-linear shadow-[0_0_10px_rgba(var(--primary),0.3)]"
              style={{ 
                width: `${progress}%`,
                transform: 'translateZ(0)'
              }}
            />
          </div>
          
          {/* Loading Text */}
          <p className="text-foreground text-sm font-medium tracking-wide">
            {Math.round(progress)}%
          </p>
        </div>
      </div>
    </div>
  );
};

export default LoadingScreen;

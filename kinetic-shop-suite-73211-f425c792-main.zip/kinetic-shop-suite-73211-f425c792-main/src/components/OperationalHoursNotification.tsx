import { useState, useEffect } from "react";
import { X, Clock } from "lucide-react";

const OperationalHoursNotification = () => {
  const [isVisible, setIsVisible] = useState(true);

  useEffect(() => {
    const timer = setTimeout(() => {
      setIsVisible(false);
    }, 5000);

    return () => clearTimeout(timer);
  }, []);

  if (!isVisible) return null;

  return (
    <div className="fixed top-4 right-4 z-50 animate-[slideInRight_0.6s_ease-out]">
      <div className="bg-gradient-to-br from-primary/90 to-primary backdrop-blur-lg rounded-2xl shadow-2xl border border-white/20 p-6 max-w-md animate-[scaleIn_0.4s_ease-out_0.2s_both]">
        <div className="flex items-start gap-4">
          <div className="bg-white/20 p-3 rounded-xl">
            <Clock className="w-6 h-6 text-white" />
          </div>
          <div className="flex-1 space-y-2">
            <h3 className="text-white font-bold text-lg">Jam Operasional</h3>
            <div className="text-white/90 text-sm space-y-1">
              <p>📅 Senin - Kamis: 07:00 - 21:00</p>
              <p>📅 Jumat - Sabtu: 08:00 - 22:00</p>
              <p>🚫 Minggu & Libur Nasional: Tutup</p>
            </div>
          </div>
          <button
            onClick={() => setIsVisible(false)}
            className="text-white/80 hover:text-white transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>
      </div>
    </div>
  );
};

export default OperationalHoursNotification;
